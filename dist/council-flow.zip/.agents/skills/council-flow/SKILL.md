---
name: council-flow
description: "Coordinate an ordinary coding goal through a Planner, parent Manager, fresh Worker, independent Tester, and independent Reviewer using native Codex subagents. Invoke explicitly with $council-flow for implementation, repair, or refactoring that needs this five-role workflow. Do not use for general questions or pretend unavailable delegation works."
---

# CouncilFlow

Invoke explicitly with $council-flow followed by an ordinary coding goal. Use native Codex tools, inherited provider/model configuration, actual workspace
permissions and budget. This is an instruction skill, not a security sandbox.
It needs no new key, subscription, database, service or custom supervisor.
Only parent **Manager** gives ordinary progress/results to the Owner.

## Required communication
Read [communication](references/communication.md), [roles](references/roles.md)
and the versioned [YAML policy](policies/roles.yaml).
Agent task assignments, plans, reports and decisions **MUST be UTF-8 JSON**
under council-flow 1.0 (1.1 for new runs with project state). Markdown/prose cannot replace them.
Keep large evidence in immutable files referenced by identity/path/SHA-256.
YAML is role/workflow policy; native custom-agent configuration remains TOML.
JSONL diagnostics are optional. Owner-facing communication stays concise natural
language; do not expose internal envelopes or long logs by default.

## Automatic project context

Before Planner, Manager follows [Codebase Memory](references/codebase-memory.md) automatically; no separate Owner command is required. Empty/install-only projects make zero MCP calls. For source, bind the actual project, check freshness and retrieve bounded context, or inspect directly if MCP is unavailable. After Worker stops edits, update the index for meaningful source; graph findings inform navigation, independent verification remains mandatory.

## Execute the goal
1. **Establish scope.** Inspect repository instructions/status and real native
   capabilities. Define the Owner objective, approved paths and observable
   acceptance. Before Planner, bind supplied frozen input and preserve test
   oracles using [source fidelity](references/source-fidelity.md). Never invent IDs or capabilities.
2. **Planner.** Follow the canonical [Planner contract](references/planner.md). Manager supplies
   bounded verified context; Planner may add read-only, cited research (documents, web, repository reads; no edits). Check a
   readiness answer with `planner_contract.py readiness`; only READY, or PROCEED_WITH_ASSUMPTIONS checked against the project budget, is dispatchable. Publish only a dispatchable
   READY plan. External mode preserves an Owner-approved plan and provenance. After validating publication,
   Each `contracts.py save` refreshes the project board `.councilflow/dashboard.html` and the run's first packet opens it once; see [workflow](references/workflow.md).
3. **Manager.** Parent accepts plan and delegates job.assign JSON to a fresh
   Worker. Validate controlled packets before dispatch and results on receipt
   using the installed contracts.py helper, known actor bindings, candidate
   hashes, source fidelity and ordered context. Save every packet, including each role's job.report, only with `contracts.py save`, which refuses bare report bodies. Before Worker dispatch, validate plan coverage and exact
   selected-task instruction transfer with scripts/planner_contract.py; copy Planner instructions exactly; apply a task's `model_hint` as advice (hint, then role default, then host model) and record the choice and reason in run evidence; never dispatch non-ready responses (ask the Owner via approval.request). With project state, follow workflow "Adaptive execution".
   Native transport is not enforced by this helper. Pass role instructions to native subagents when custom-role
   selection is unavailable, and disclose that fallback.
4. **Worker.** Implement only bounded work, perform developer checks, return
   job.report JSON with actual candidate/evidence and changed files, then stop
   edits. Worker cannot approve itself. Manager writes no application code.
   One Worker mutates a workspace; parallel implementation requires authorized
   isolated workspaces.
5. **Tester.** Fresh separate native Tester independently executes original
   acceptance and the approved verification strategy on the exact candidate.
   For each suitable deterministic command, record the exact executable path in
   `command`, arguments, working directory, candidate and relevant input identities/hashes, exit code, SHA-256
   of stdout after CRLF-to-LF replacement only, criterion ID and evidence artifact.
   A declaration alone does not prove determinism. Do not repair product or approve
   the oracle.
6. **Reviewer.** Compare the frozen plan and criteria, Worker candidate and
   Tester's recorded technical evidence. Receive and preserve the exact Tester
   command/executable path, arguments, working directory, candidate and relevant
   input references. Independently rerun that declared executable without a
   shell alias; capture raw stdout/exit, apply CRLF-to-LF-only
   normalization and SHA-256, and report both results and evidence to Manager.
   Matching proves repeatability only for that command and recorded conditions.
   Mismatches preserve both results and fail review; no command is
   NOT_COMPARABLE and cannot pass E8. Do not implement, alter criteria, or perform
   generalized UX evaluation.
7. **Rework.** Manager records task.decision JSON from evidence: accept, reject,
   rework or escalate. When the original Planner check finds unmet criteria,
   rework must reply to that exact check and preserve every failed criterion and
   its evidence. Failed mandatory checks cannot be accepted. Repairs use
   a fresh Worker/attempt under unchanged criteria, then affected independent
   checks. Follow [recovery](references/recovery.md); no lifetime engineering
   repair cap. Infrastructure retry 3/crash recovery 2 are instruction-only
   policy, not runtime accounting.
8. **Final Planner check.** Manager sends verified plan.progress JSON. Planner
   repeats source fidelity validation and returns plan.check against original acceptance, not a rewritten
   Worker checklist. Manager gives the Owner concise natural-language results
   using [acceptance](references/acceptance.md).

## Optional routing hint
`scripts/route.py` is an opt-in local classifier, off unless the Owner supplies a route config. It emits hashes and confidence; Manager validates, accepts, ignores, or overrides the hint and records that choice (see [communication](references/communication.md)). It cannot dispatch roles, authorize tools, select an unobserved provider or model, expand scope, or alter packets.

## Evidence and limits
Efficiency stays disabled unless explicitly requested; then follow [efficiency helpers](references/efficiency.md) using this installed skill's CLI, preserving full evidence and all mandatory roles/checks.
Follow [workflow](references/workflow.md) and the [dispatch checklist](references/manager-dispatch-checklist.md) (validate every packet before dispatch and every report on receipt). Keep real task/plan/attempt/message IDs,
validated causal order, causal references, commands/exits and evidence hashes.
Agent-authored envelopes omit `created_at`; diagnostic timestamp syntax does not
prove trusted clock provenance. Structural
validation is not sender authentication, native-transport control or OS isolation.
Without supplied context, only structure is checked; disclose missing context.
No JSON/YAML declaration grants filesystem, network, execution or approval power.

Ordinary in-scope repair needs no repeated Owner approval. Consequential new
scope/authorization and required subjective decisions belong to the Owner.
Use approval.request only for a concrete necessary decision; record
approval.decision only from actual Owner input/provenance, never AI invention.
Refuse unauthorized external changes without attempting permission bypass.

If native discovery, invocation, a role, test or actual interaction is unavailable,
record UNVERIFIED/BLOCKED. Never simulate agents or upgrade static checks into
live proof. Preserve useful work and report the exact gap. Contract restoration
with blocked activation is CONTRACT_RESTORED — NATIVE_ACTIVATION_UNVERIFIED;
COUNCILFLOW_FULLY_VERIFIED requires genuine invocation and real required roles.
