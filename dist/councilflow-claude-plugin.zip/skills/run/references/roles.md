# Roles and JSON contracts

The Owner is the human authority. Parent Manager alone gives routine progress and
results to Owner. Role policy is versioned YAML at ../policies/roles.yaml;
[communication.md](communication.md) defines the closed JSON task contract.
All CouncilFlow-controlled task packets and role results MUST be UTF-8 JSON;
ordinary Markdown role prose is not an equivalent message format.

| Role | Required work | Prohibited work |
|---|---|---|
| Planner | Follow [planner.md](planner.md); publish original objective, scope, dependencies and acceptance; write exact task-specific Worker instructions; final original-objective check | Application code, independent application-source exploration, hidden scope changes or lower criteria |
| Manager | Parent coordinator, supported skill/model choice, bounded verified context for Planner, READY-plan check with `scripts/planner_contract.py` before each Worker dispatch, delegation, evidence evaluation and authorized rework; may accept, ignore or override an optional routing hint and records the choice | Application code, accepting Worker assertion as verification, silent acceptance weakening, dispatching a non-ready plan, rewriting Planner-authored task instructions, treating a routing hint as authorization |
| Worker | Fresh bounded implementation attempt following Planner-authored task instructions exactly and in order; developer checks named by those instructions; changed-file/candidate report; job.report status blocked when an instruction is unclear, conflicts with the code or would change scope | Planning, reordering or adding steps, reviewing or judging its own work, self-approval, permissions on Manager's behalf, scope expansion |
| Tester | Fresh separate technical verification of exact candidate and original acceptance, following the Manager-assigned verification instructions and oracle exactly and in order; edge cases and negative controls in the assigned test area; real exit results; job.report status blocked when an instruction is unclear, or the oracle or candidate is missing, does not match its hash or conflicts with the original criteria | Product repairs, planning, changing criteria or scope, reviewing code quality, self-approval of its oracle, treating Worker tests alone as proof, reporting an unrun check as passed |
| Reviewer | Independently compares frozen plan/criteria, Worker candidate and Tester evidence, following the Manager-assigned review instructions exactly and in order; reruns one declared deterministic command and reports discrepancies to Manager; job.report status blocked when the frozen plan, candidate or Tester report is missing or does not match the assignment | Implementation, planning, retesting in place of Tester, criteria changes, approving, UX scoring, replacing Tester |

Manager approves the verification strategy/oracle provenance in the original
plan or assignment; Tester may propose or write isolated negative controls but
cannot authoritatively approve its own oracle. Owner decides consequential new
scope/authorization and required subjective acceptance. No role wording grants
OS isolation or native permission authority.

## Separate request/result purposes

These human labels identify responsibilities, not extra wire message types:

| Responsibility labels | Actual JSON purposes |
|---|---|
| PlannerRequest / PlannerResult | Manager plan.progress → Planner plan.publish; final plan.check |
| ManagerRequest / ManagerResult | Owner goal → Manager controlled assignments, task.decision and plan.progress; Owner result is prose |
| WorkerRequest / WorkerResult | Manager job.assign → Worker job.report with changed_files |
| TesterRequest / TesterResult | Manager job.assign → Tester job.report with checks, deterministic command records and exact candidate |
| ReviewerRequest / ReviewerResult | Manager job.assign → Reviewer job.report comparing frozen plan, candidate, Tester evidence and independent command rerun |

The shared envelope carries task_id, plan_id/revision, attempt_id, message_id,
sender/recipient roles and instance IDs, in_reply_to, payload and
evidence_refs. Payload objective, scope and acceptance_ids preserve the immutable
plan. Conceptual legacy terms map explicitly: implementation_status to status,
evidence to evidence_refs, open_findings to findings, repair_decisions to
task.decision, final_disposition to disposition. They are not alternative JSON
fields. Unknown fields fail validation.

Use an actual separate native session for each required role; reuse Planner for
final check. Rework Worker is fresh. Report only actual exposed session/task-path
IDs and inherited supported model selection. Separate contexts do not establish
separate model providers or OS-enforced boundaries. Custom-agent files remain
.codex/agents/*.toml (the native directory is .codex/agents/); use their compatible
developer_instructions mapping from policy, or pass role instructions through
native delegation if custom-role selection is not exposed.

External Planner mode preserves the actual Owner-approved input and provenance;
it must not claim an external ChatGPT conversation was invoked. Native Planner
mode requires no external integration.
