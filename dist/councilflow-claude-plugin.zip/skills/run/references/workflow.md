# Operational workflow and controlled boundaries

Owner → Planner → parent Manager → Worker → Tester → Reviewer → Manager →
Planner final check → Owner. Preserve that responsibility order.

1. Inspect authorized repository, original goal, instructions, status and actual
   tools. Read policies/roles.yaml and communication.md. The native sandbox and
   actual Owner authorization remain authoritative. Manager performs the
   [Codebase Memory lifecycle](codebase-memory.md) and
   [original-input/oracle capture](source-fidelity.md) before Planner automatically.
   An optional routing hint may classify the bounded task before planning, but
   Manager validates the route hint and may ignore or override it, recording the
   choice (see communication.md). Routing never grants scope, tool authorization,
   model identity, or role dispatch. Manager supplies Planner with the bounded
   verified context the plan needs; Planner does not explore application source.
2. Dedicated Planner follows [planner.md](planner.md) and returns plan.publish JSON with exact immutable acceptance
   and plan artifact/hash. External mode preserves a supplied Owner-approved
   plan verbatim, with provenance; do not claim contact with external ChatGPT.
   Supplied frozen criteria always require the pre-Planner original-input
   reference, not another agent's derivative. Before dispatch Manager runs
   sequence validation with `--require-criteria-fidelity --original-source-ref`
   and actual caller-observed `--owner-provenance`, as specified in source-fidelity.md.
   The plan preserves `original_source_ref`; exact ordered text is derived from
   the raw source bytes. Missing, stale, substituted or mismatching sources block dispatch.
   Preserve rejected plans and evidence; corrections require a new plan through
   the existing authorized workflow. All roles use stable IDs and the immutable
   artifact instead of rewriting criterion text. Ordinary requests without
   supplied frozen criteria may generate a native plan, preserving the actual
   request and distinguishing generated acceptance.
3. Manager constructs bounded job.assign JSON with objective, scope, original
   acceptance IDs, exact candidate reference and instructions. For each Worker
   assignment, validate the READY plan against frozen criteria and verify the
   plan ID/revision, task ID, acceptance IDs and Planner-authored instruction
   array exactly match that selected task using
   `scripts/planner_contract.py assignment <plan.json> <frozen-criteria.json> <assignment.json>`.
   Also validate the controlled packet, file hashes and any required criteria
   fidelity before delegation. Non-ready responses are not published or dispatched;
   Manager keeps them as evidence and asks the Owner through approval.request.
   Manager copies Planner task instructions exactly and never rewrites them.
   Supply known native
   actor bindings from actual tool metadata, never from self-asserted role text.
4. Fresh Worker implements, runs developer checks and returns job.report JSON.
   Validate on receipt and wait for it to stop edits. Parent Manager does not
   implement application code. Only one Worker mutates this workspace.
   Manager then synchronizes the available Codebase Memory index with the
   resulting source before passing context to independent agents; repeat after
   rework. Failed or unavailable indexing uses the documented source fallback.
5. Fresh independent Tester receives the approved verification strategy and exact
   candidate hash in its own job.assign. It executes original acceptance and
   meaningful negative controls, returns technical job.report, and never repairs.
   Worker self-report alone cannot satisfy acceptance.
6. Fresh independent Reviewer receives job.assign after Tester evidence and
   compares the original plan, candidate and Tester report. It independently
   reruns one Tester-declared deterministic command, captures its own output/exit
   evidence, and reports both hashes, comparison, discrepancies and missing
   evidence to Manager. A match supports repeatability for that command only;
   NOT_COMPARABLE does not pass E8.
7. Manager records task.decision JSON, linking original criteria and actual
   reports/evidence. Mandatory failure triggers rejection/rework or a precise
   blocker. Fresh Worker repair preserves acceptance and authorization, followed
   by affected independent rechecks. See recovery.md.
8. Manager sends verified plan.progress; original Planner returns plan.check
   mapping every original criterion. Manager reconciles all evidence and gives
   Owner concise prose: requested, implemented, tests, Reviewer, open gaps and
   any genuinely necessary Owner decision.
   For required frozen-criteria invocations, repeat exact fidelity validation
   against the original trusted reference before accepting this final check.

## Practical file boundary

For Codex runs, Manager stores each task's packet files in
`.councilflow/runs/<task-id>/`, with messages in its `messages/` folder. Use
ordinary bounded files, for example `messages/M001.json`, `candidate.json` and
`test-output.txt`, referenced by artifact identity/path/SHA-256. Validate UTF-8 JSON
using scripts/contracts.py. Save every packet into `messages/` only with
`contracts.py save <packet.json> --run .councilflow/runs/<task-id> --root .`:
Planner packets, every `job.assign` (Worker, Tester and Reviewer), every
`job.report`, `task.decision`, `plan.progress` and `plan.check`. It refuses a
bare report body without the council-flow envelope, a packet that fails
`message` or breaks the run order, and an existing message id; a refused packet
is kept outside `messages/` as evidence, never rewritten to pass. Do not write
packets into `messages/` by hand or as Markdown. Ordered message context checks causal links,
attempt/candidate identities, published acceptance and known actor bindings.
Refer to communication.md for exact schemas, CLI and limitations. This is not a
database, message broker, Supervisor, agent simulator or transport adapter.

The read-only dashboard follows the run without a separate Manager step. Each
successful `contracts.py save` into `.councilflow/runs/<task-id>` republishes the
task board and the project board `.councilflow/dashboard.html`, which always shows
the run this project saved to most recently. The run's first saved packet
(normally `plan.publish`) opens the project board once in the default browser;
`--no-open`, `CI` or `COUNCILFLOW_NO_BROWSER` keep it closed and `--no-dashboard`
skips the refresh. The save output reports the board under `dashboard`. A board
failure never undoes or blocks the save. Manager may still run
`scripts/dashboard.py publish --root . --task-id <task-id> [--open]` by hand, for
example to add `--efficiency-records`. The dashboard is an informational
projection; packets remain authoritative, and no local service or watcher is
started. If the host cannot open the browser (`"opened": false`), report the
dashboard as blocked and continue the normal workflow without claiming a live
connection.

Native Codex transport may wrap these messages in an opaque protocol. CouncilFlow
only controls the task packet/report files and instructions passed through
supported native tools; never claim the helper enforces the underlying transport.
Structure is not authentication; YAML cannot grant OS permissions.

Optional diagnostics are bounded one-object-per-line JSONL, tied to real messages
and evidence, never raw prompts/secrets/reasoning. No event file is represented
as authoritative crash-safe accounting. Owner never has to inspect JSON/YAML/
JSONL during ordinary work.

## Native compatibility and truthful gaps

Keep .codex/agents/*.toml in native format. YAML policy responsibilities map to
developer_instructions; do not invent native keys or unsupported models.
If custom-role selection is missing but real native agents work, pass role
instructions to separate native sessions and disclose unverified file selection.
If native roles are unavailable, preserve useful artifacts and mark that run
blocked. Never rename sequential self-assessments as distinct agents.

Native discovery/explicit invocation require actual host evidence. Reading files
or validating example JSON is not activation proof. Preserve historical bootstrap
packets with their limits, then start actual fully validated exchanges after the
contract exists. No fake migrated history or manufactured approvals.

Example ordinary invocation: $council-flow Implement an offline receipt calculator
inside this repository with tests. The Owner need not author internal packets.
